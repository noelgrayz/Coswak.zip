//Main class
public class Animal {
    // Variables for name and age
    private String name;
    private int age;

    // Constructor to initialize name and age
    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Method to make sound
    public void makeSound() {
        System.out.println("Animal is making a sound");
    }

    // Overloaded method to make sound multiple times
    public void makeSound(int times) {
        for (int i = 0; i < times; i++) {
            makeSound();
        }
    }

    // Method for eating
    public void eat() {
        System.out.println("Animal is eating");
    }

    // Overloaded method for eating a specific type of food
    public void eat(String foodType) {
        System.out.println("Animal is eating " + foodType);
    }
}
