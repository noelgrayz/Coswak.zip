//The  main method to execute the project
public class Zoo {
    public static void main(String[] args) {
        // Create instances of Lion, Elephant, and Monkey
        Animal lion = new Lion("Leo", 5);
        Animal elephant = new Elephant("Dumbo", 10);
        Animal monkey = new Monkey("George", 3);

        // Demonstrate the makeSound and eat methods
        lion.makeSound();
        lion.eat();
        lion.makeSound(3);
        lion.eat("meat");

        elephant.makeSound();
        elephant.eat();
        elephant.makeSound(2);
        elephant.eat("grass");

        monkey.makeSound();
        monkey.eat();
        monkey.makeSound(4);
        monkey.eat("bananas");
    }
}
