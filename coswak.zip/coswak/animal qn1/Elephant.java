//  The Elephant class that inherits from Animal
public class Elephant extends Animal {
    // Constructor to initialize name and age
    public Elephant(String name, int age) {
        super(name, age);  // Call the constructor of the superclass (Animal)
    }

    // Override makeSound() method
    @Override
    public void makeSound() {
        System.out.println("Trumpet");
    }

    // Override eat() method
    @Override
    public void eat() {
        System.out.println("Eating grass");
    }
}
